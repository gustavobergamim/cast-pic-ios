//
//  CGListaEstadoControllerTableViewController.h
//  estados-do-brasil
//
//  Created by Gustavo Bergamim on 06/12/2017.
//  Copyright © 2017 Cast Group. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CGListaEstadoControllerTableViewController : UITableViewController

@end
