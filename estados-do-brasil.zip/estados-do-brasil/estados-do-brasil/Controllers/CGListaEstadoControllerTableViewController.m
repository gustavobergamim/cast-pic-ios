//
//  CGListaEstadoControllerTableViewController.m
//  estados-do-brasil
//
//  Created by Gustavo Bergamim on 06/12/2017.
//  Copyright © 2017 Cast Group. All rights reserved.
//

#import "CGListaEstadoControllerTableViewController.h"
#import "CGCelulaEstadoTableViewCell.h"
#import "CGServiceEstado.h"
#import "CGEstado.h"

@interface CGListaEstadoControllerTableViewController ()

@property (nonatomic, strong) NSArray *listaEstados;
@property (nonatomic, strong) NSDictionary *listaEstadosPorRegiao;

@end

@implementation CGListaEstadoControllerTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    CGServiceEstado *service = [CGServiceEstado new];
    self.listaEstados = [service recuperarEstados];
    self.listaEstadosPorRegiao = [service recuperarEstadosPorRegiao];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (NSString*) obterNomeImagem:(NSString *)nomeEstado
{
    NSData *data = [nomeEstado dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    NSString *nomeImagem = [[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding];
    nomeImagem = [nomeImagem lowercaseString];
    nomeImagem = [nomeImagem stringByReplacingOccurrencesOfString:@" " withString:@"_"];
    return nomeImagem;
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return self.listaEstadosPorRegiao.allKeys.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    NSArray *listaEstadosRegiao = [self.listaEstadosPorRegiao objectForKey:@(section)];
    return listaEstadosRegiao.count;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    switch (section) {
        case CGEnumRegiaoNorte:
            return @"Norte";
        case CGEnumRegiaoNordeste:
            return @"Nordeste";
        case CGEnumRegiaoCentroOeste:
            return @"Centro-Oeste";
        case CGEnumRegiaoSudeste:
            return @"Sudeste";
        case CGEnumRegiaoSul:
            return @"Sul";
        default:
            return @"";
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    CGCelulaEstadoTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cellEstado" forIndexPath:indexPath];
    
    NSArray *listaEstadosRegiao = [self.listaEstadosPorRegiao objectForKey:@(indexPath.section)];
    
    CGEstado *estado = listaEstadosRegiao[indexPath.row];
    
    cell.imagemBandeira.image = [UIImage imageNamed:[self obterNomeImagem:estado.nome]];
    cell.labelEstado.text = estado.nome;
    cell.labelCapital.text = estado.capital;
    
    return cell;
}


/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
